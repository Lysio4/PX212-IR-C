#ifndef _PILE_H
#define _PILE_H

/* Ici, on est oblig� d'utiliser la notation struct xxx,
car la structure s'auto-r�f�rence!*/
typedef struct node {
		char data ;
		struct node *link ;
		} Lnode ;

void insertionTete(Lnode **ph,char item);
void insertionQueue(Lnode **ph,char item);
void suppressionTete(Lnode **ph);
void suppressionQueue(Lnode **ph);
void listeAffiche(Lnode * ptr);

#endif
