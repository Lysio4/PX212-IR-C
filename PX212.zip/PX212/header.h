#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

//constantes
#define Largeur 100
#define Longueur 100



//Fonctions.c


//sokoban.c


//io.c + touches.c

int test();
void touches(int niveau);

//pile.c
