#ifndef _IO_H
#define _IO_H

int configureTerminal();
int litClavier();

#endif
